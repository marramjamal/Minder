export const FONT_REGULAR = "Roboto-Regular";
export const FONT_BOLD = "Roboto-Bold";
export const FONT_MEDIUM = "Roboto-Medium";
