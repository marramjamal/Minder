export const primary_color = "#7264E9";
export const primary_color_light = "#F5FAFF";
export const bg_color = "#FFFFFF";
export const splash_color = "#ffffff";
