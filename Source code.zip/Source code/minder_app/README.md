# FaceX
React native application for Alzheimer's patient provide medication timings, activities, face recognition.
